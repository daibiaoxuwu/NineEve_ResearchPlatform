```
# If you want to connect the frontend with the backend_simulator:
# If you have changed something in the frontend:
# In the "frontend", build for production with minification
npm run build
# 如果端口号是80，则加sudo
# Then goto "backend_simulator"
node bs_1.js
# 如果端口号是80，则加sudo
```
